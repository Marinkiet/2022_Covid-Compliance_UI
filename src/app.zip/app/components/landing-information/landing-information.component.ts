import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing-information',
  templateUrl: './landing-information.component.html',
  styleUrls: ['./landing-information.component.css']
})
export class LandingInformationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
