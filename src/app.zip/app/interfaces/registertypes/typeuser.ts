export interface Typeuser
{
    id:number;
    type:string;
}
