import { Typeuser } from './typeuser';

export const Typelist:Typeuser[]=
[
    { id:1,type: 'Staff' },
    { id:2,type: 'Visitor' },
   
]
