export interface ViewImage
{
    pic_path:string;
    pictureName:string;
    image_id:number;
} 

/* export class FileToUpload
{
    pic_path:string="";
    fileAsBase64: string = "";
} */
