import { Typeuser } from './typeuser';

export const Typelist:Typeuser[]=
[
    {id:1,type:'Admin'},
    { id: 2, type: 'Officer' },
    { id: 3, type: 'Student' },
    { id: 4, type: 'Visitor' },
    { id: 5, type: 'Staff' }
]
